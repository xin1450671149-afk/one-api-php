<?php
// 开启Session
session_start();

// 加载配置
require_once __DIR__ . '/../config/config.php';

// 路由逻辑
$request_uri = $_SERVER['REQUEST_URI'];
$base_path = '/'; // 如果部署在子目录，请修改此处，例如 /oneapi/

// 移除查询参数
$path = parse_url($request_uri, PHP_URL_PATH);

// 移除 Base Path 前缀
if (strpos($path, $base_path) === 0) {
    $path = substr($path, strlen($base_path));
}
$path = trim($path, '/');

// 路由映射表
$routes = [
    '' => ['HomeController', 'index'],
    'login' => ['UserController', 'login'],
    'register' => ['UserController', 'register'],
    'logout' => ['UserController', 'logout'],
    'dashboard' => ['UserController', 'dashboard'],
    'recharge' => ['UserController', 'recharge'],
    'token/create' => ['UserController', 'createToken'],
    'token/delete' => ['UserController', 'deleteToken'],
    
    // Admin Routes
    'admin/login' => ['AdminController', 'login'],
    'admin/dashboard' => ['AdminController', 'dashboard'],
    'admin/channels' => ['AdminController', 'channels'],
    'admin/users' => ['AdminController', 'users'],
    'admin/logs' => ['AdminController', 'logs'],
    'admin/settings' => ['AdminController', 'settings'],
];

// API 路由特殊处理
if ($path === 'v1/chat/completions') {
    require_once __DIR__ . '/../app/Controller/ApiController.php';
    $apiController = new ApiController($pdo);
    $apiController->chatCompletions();
    exit;
}

// 匹配路由
if (array_key_exists($path, $routes)) {
    [$controllerName, $actionName] = $routes[$path];
    $controllerFile = __DIR__ . '/../app/Controller/' . $controllerName . '.php';
    
    if (file_exists($controllerFile)) {
        require_once $controllerFile;
        $controller = new $controllerName($pdo);
        $controller->$actionName();
        exit;
    }
}

// 默认 404
http_response_code(404);
echo "404 Not Found";

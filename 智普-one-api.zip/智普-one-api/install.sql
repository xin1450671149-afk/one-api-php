-- 数据库结构

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+08:00";

--
-- 表的结构 `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL COMMENT '用户名',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `role` int(1) NOT NULL DEFAULT 0 COMMENT '角色 0普通用户 1管理员',
  `balance` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '余额',
  `quota` bigint(20) NOT NULL DEFAULT 0 COMMENT '额度',
  `status` int(1) NOT NULL DEFAULT 1 COMMENT '状态 1正常 0封禁',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `balance`, `quota`, `status`, `created_at`) VALUES
(1, 'xindska', '$2y$10$vI8aWBnW3fID.ZQ4/zo1G.q1lRps.9cGLcZEiGDMVr5yUP1nERZSa', 1, 1000.00, 10000000, 1, '2023-01-01 00:00:00');
-- 默认密码 seed123destiny 的 hash 值 (使用 PHP password_hash 生成)

-- --------------------------------------------------------

--
-- 表的结构 `tokens`
--

CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `key` varchar(64) NOT NULL COMMENT '令牌密钥',
  `name` varchar(32) NOT NULL COMMENT '令牌名称',
  `status` int(1) NOT NULL DEFAULT 1 COMMENT '状态 1启用 0禁用',
  `remain_quota` bigint(20) NOT NULL DEFAULT 0 COMMENT '剩余额度',
  `unlimited_quota` int(1) NOT NULL DEFAULT 0 COMMENT '无限额度 1是 0否',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accessed_at` datetime DEFAULT NULL COMMENT '最后访问时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `channels`
--

CREATE TABLE `channels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT 1 COMMENT '渠道类型',
  `name` varchar(32) NOT NULL COMMENT '渠道名称',
  `base_url` varchar(255) NOT NULL COMMENT '代理地址',
  `key` text NOT NULL COMMENT '密钥',
  `models` text NOT NULL COMMENT '支持模型',
  `pricing_type` int(1) NOT NULL DEFAULT 1 COMMENT '计费类型 1按次 2按Token',
  `price` decimal(10,4) NOT NULL DEFAULT 0.0000 COMMENT '价格',
  `status` int(1) NOT NULL DEFAULT 1 COMMENT '状态 1启用 0禁用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `type` int(1) NOT NULL DEFAULT 0 COMMENT '类型 1充值 2消费',
  `content` text NOT NULL COMMENT '详情',
  `token_name` varchar(32) DEFAULT NULL COMMENT '令牌名称',
  `model_name` varchar(32) DEFAULT NULL COMMENT '模型名称',
  `quota` int(11) NOT NULL DEFAULT 0 COMMENT '消耗额度',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `options`
--

CREATE TABLE `options` (
  `key` varchar(32) NOT NULL,
  `value` text,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `options` (`key`, `value`) VALUES
('site_name', 'One API PHP版'),
('payment_enabled', '1');

COMMIT;

<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'one_api');
define('DB_USER', 'root');
define('DB_PASS', 'root'); // 请根据实际情况修改

// 网站配置
define('SITE_NAME', 'One API PHP版');
define('SITE_URL', 'http://localhost'); // 请修改为实际域名

// 时区设置
date_default_timezone_set('Asia/Shanghai');

// 数据库连接
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

// 辅助函数：JSON响应
function jsonResponse($code, $message, $data = []) {
    header('Content-Type: application/json');
    echo json_encode([
        'code' => $code,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

// 辅助函数：重定向
function redirect($url) {
    header("Location: $url");
    exit;
}

// 辅助函数：获取当前用户
function getCurrentUser() {
    if (isset($_SESSION['user'])) {
        return $_SESSION['user'];
    }
    return null;
}

// 辅助函数：生成随机字符串
function generateRandomString($length = 32) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

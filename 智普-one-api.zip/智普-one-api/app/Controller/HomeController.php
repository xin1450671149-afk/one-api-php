<?php

class HomeController {
    protected $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function index() {
        // 显示首页
        require_once __DIR__ . '/../View/home.php';
    }

    public function login() {
        // 显示登录页面
        require_once __DIR__ . '/../View/user/login.php';
    }

    public function register() {
        // 显示注册页面
        require_once __DIR__ . '/../View/user/register.php';
    }

    public function dashboard() {
        // 用户仪表盘
        if (!isset($_SESSION['user'])) {
            header('Location: /login');
            exit;
        }
        $user = $_SESSION['user'];
        require_once __DIR__ . '/../View/user/dashboard.php';
    }

    public function admin() {
        // 管理员登录/后台
        if (isset($_SESSION['admin'])) {
            header('Location: /admin/dashboard');
            exit;
        }
        require_once __DIR__ . '/../View/admin/login.php';
    }
}

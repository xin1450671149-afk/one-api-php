<?php

class AdminController {
    protected $db;

    public function __construct($db) {
        $this->db = $db;
    }

    private function checkAuth() {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 1) {
            header('Location: /login');
            exit;
        }
    }

    public function index() {
        $this->checkAuth();
        require_once __DIR__ . '/../View/admin/dashboard.php';
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];

            $stmt = $this->db->prepare("SELECT * FROM users WHERE username = ? AND role = 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user'] = $user;
                header('Location: /admin/dashboard');
                exit;
            } else {
                $error = "管理员账号或密码错误";
                require_once __DIR__ . '/../View/admin/login.php';
            }
        } else {
            require_once __DIR__ . '/../View/admin/login.php';
        }
    }

    public function dashboard() {
        $this->checkAuth();
        // Stats
        $stmt = $this->db->query("SELECT COUNT(*) as user_count FROM users");
        $user_count = $stmt->fetchColumn();
        
        $stmt = $this->db->query("SELECT COUNT(*) as channel_count FROM channels");
        $channel_count = $stmt->fetchColumn();
        
        $stmt = $this->db->query("SELECT SUM(quota) as total_quota FROM logs WHERE type = 2");
        $total_quota = $stmt->fetchColumn();

        require_once __DIR__ . '/../View/admin/dashboard.php';
    }

    public function channels() {
        $this->checkAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Handle add/edit
            $action = $_POST['action'] ?? 'add';
            if ($action === 'add') {
                $name = $_POST['name'];
                $type = $_POST['type'];
                $base_url = $_POST['base_url'];
                $key = $_POST['key'];
                $models = $_POST['models'];
                $pricing_type = $_POST['pricing_type'];
                $price = $_POST['price'];

                $stmt = $this->db->prepare("INSERT INTO channels (name, type, base_url, `key`, models, pricing_type, price) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $type, $base_url, $key, $models, $pricing_type, $price]);
            } elseif ($action === 'edit') {
                $id = $_POST['id'];
                $name = $_POST['name'];
                $type = $_POST['type'];
                $base_url = $_POST['base_url'];
                $key = $_POST['key'];
                $models = $_POST['models'];
                $pricing_type = $_POST['pricing_type'];
                $price = $_POST['price'];

                $stmt = $this->db->prepare("UPDATE channels SET name = ?, type = ?, base_url = ?, `key` = ?, models = ?, pricing_type = ?, price = ? WHERE id = ?");
                $stmt->execute([$name, $type, $base_url, $key, $models, $pricing_type, $price, $id]);
            } elseif ($action === 'delete') {
                $id = $_POST['id'];
                $stmt = $this->db->prepare("DELETE FROM channels WHERE id = ?");
                $stmt->execute([$id]);
            }
            
            header('Location: /admin/channels');
            exit;
        }

        $stmt = $this->db->query("SELECT * FROM channels ORDER BY id DESC");
        $channels = $stmt->fetchAll();
        
        require_once __DIR__ . '/../View/admin/channels.php';
    }

    public function users() {
        $this->checkAuth();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = $_POST['action'];
            if ($action === 'delete') {
                $id = $_POST['id'];
                $stmt = $this->db->prepare("DELETE FROM users WHERE id = ?");
                $stmt->execute([$id]);
            } elseif ($action === 'add_balance') {
                $id = $_POST['id'];
                $amount = $_POST['amount'];
                $stmt = $this->db->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                $stmt->execute([$amount, $id]);
            }
            header('Location: /admin/users');
            exit;
        }

        $stmt = $this->db->query("SELECT * FROM users ORDER BY id DESC");
        $users = $stmt->fetchAll();

        require_once __DIR__ . '/../View/admin/users.php';
    }

    public function logs() {
        $this->checkAuth();
        
        $page = $_GET['page'] ?? 1;
        $limit = 50;
        $offset = ($page - 1) * $limit;
        
        $stmt = $this->db->prepare("SELECT l.*, u.username FROM logs l LEFT JOIN users u ON l.user_id = u.id ORDER BY l.created_at DESC LIMIT ? OFFSET ?");
        // PDO limit requires integer binding or direct value
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->bindValue(2, $offset, PDO::PARAM_INT);
        $stmt->execute();
        $logs = $stmt->fetchAll();

        require_once __DIR__ . '/../View/admin/logs.php';
    }
    
    public function settings() {
        $this->checkAuth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            foreach ($_POST as $key => $value) {
                if ($key !== 'action') {
                    $stmt = $this->db->prepare("INSERT INTO options (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = ?");
                    $stmt->execute([$key, $value, $value]);
                }
            }
            header('Location: /admin/settings');
            exit;
        }
        
        $stmt = $this->db->query("SELECT * FROM options");
        $options_raw = $stmt->fetchAll();
        $options = [];
        foreach ($options_raw as $opt) {
            $options[$opt['key']] = $opt['value'];
        }
        
        require_once __DIR__ . '/../View/admin/settings.php';
    }
}

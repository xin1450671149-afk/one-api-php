<?php

class ApiController {
    protected $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function chatCompletions() {
        // 设置脚本执行时间为不限制，防止 PHP 超时
        set_time_limit(0);

        // 1. 验证 Authorization
        $headers = getallheaders();
        $authHeader = $headers['Authorization'] ?? '';
        if (!preg_match('/Bearer\s+(sk-[a-zA-Z0-9]+)/', $authHeader, $matches)) {
            $this->jsonResponse(401, 'Invalid Authorization header');
        }
        $key = $matches[1];

        // 验证令牌
        $stmt = $this->db->prepare("SELECT * FROM tokens WHERE `key` = ? AND status = 1");
        $stmt->execute([$key]);
        $token = $stmt->fetch();

        if (!$token) {
            $this->jsonResponse(401, 'Invalid API Key');
        }

        // 获取用户信息
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$token['user_id']]);
        $user = $stmt->fetch();

        if ($user['status'] != 1) {
            $this->jsonResponse(403, 'User is banned');
        }

        if ($user['balance'] <= 0 && $user['quota'] <= 0) {
            $this->jsonResponse(402, 'Insufficient quota');
        }

        // 2. 解析请求
        $input = file_get_contents('php://input');
        $requestData = json_decode($input, true);
        
        if (!isset($requestData['model'])) {
            $this->jsonResponse(400, 'Model is required');
        }
        
        $model = $requestData['model'];
        $stream = $requestData['stream'] ?? false;

        // 3. 寻找可用渠道
        $stmt = $this->db->prepare("SELECT * FROM channels WHERE status = 1 AND models LIKE ? ORDER BY RAND() LIMIT 1"); // 简单随机负载
        $stmt->execute(['%' . $model . '%']);
        $channel = $stmt->fetch();

        if (!$channel) {
            $this->jsonResponse(404, 'No channel available for model: ' . $model);
        }

        // 4. 转发请求
        $baseUrl = rtrim($channel['base_url'], '/');
        $targetUrl = '';

        if (strpos($baseUrl, 'open.bigmodel.cn') !== false) {
             // 智普 AI 特殊处理
             // 1. 如果用户填写了完整路径 https://open.bigmodel.cn/api/paas/v4 -> 直接拼 /chat/completions
             if (strpos($baseUrl, '/api/paas/v4') !== false) {
                 $targetUrl = $baseUrl . '/chat/completions';
             } else {
                 // 2. 如果用户只填了 https://open.bigmodel.cn -> 自动补全 /api/paas/v4/chat/completions
                 $targetUrl = $baseUrl . '/api/paas/v4/chat/completions';
             }
        } else {
             // 默认 OpenAI 格式: Base URL + /v1/chat/completions
             $targetUrl = $baseUrl . '/v1/chat/completions';
        }
        
        // 替换 Auth Key
        $channelKey = $channel['key']; // 可能是池，这里简化为单个
        // 如果是多Key，可以用换行符分割并随机取一个
        $keys = explode("\n", $channelKey);
        $useKey = trim($keys[array_rand($keys)]);

        // 准备转发
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $targetUrl);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $useKey
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        // 设置超时时间 (360秒)
        curl_setopt($ch, CURLOPT_TIMEOUT, 360);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
        
        // 处理流式
        if ($stream) {
            curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) use ($user, $model, $channel) {
                echo $data;
                flush();
                // 统计Token逻辑 (流式较难精确统计，这里简化处理，可以在结束后统计)
                // 实际生产中通常需要累积 buffer 并计算 content 长度
                return strlen($data);
            });
        }

        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            $this->jsonResponse(500, 'Upstream error: ' . curl_error($ch));
        }
        
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if (!$stream) {
            // 非流式直接输出
            http_response_code($httpCode);
            echo $response;
            
            // 5. 计费逻辑 (非流式)
            $responseData = json_decode($response, true);
            $usage = 0;
            
            // 按次计费
            if ($channel['pricing_type'] == 1) { // 按次
                $cost = $channel['price']; // 0.01
                $usage = 1;
            } else { // 按Token/字数
                // 简易计算：输入+输出字符数
                $inputChars = 0;
                foreach ($requestData['messages'] as $msg) {
                    $inputChars += mb_strlen($msg['content']);
                }
                
                $outputChars = 0;
                if (isset($responseData['choices'][0]['message']['content'])) {
                    $outputChars = mb_strlen($responseData['choices'][0]['message']['content']);
                }
                
                $totalChars = $inputChars + $outputChars;
                // 0.001 per 1000 chars -> totalChars / 1000 * 0.001
                $cost = ($totalChars / 1000) * $channel['price'];
                $usage = $totalChars;
            }

            // 扣费
            if ($cost > 0) {
                $this->deductBalance($user['id'], $cost, $model, $usage);
            }
        } else {
             // 流式计费比较复杂，通常需要在 writefunction 中累积
             // 这里简化：假设每次流式调用扣除固定费用或后续异步处理
             // 为了演示，这里暂不处理流式精确计费，建议按次或者预估
             if ($channel['pricing_type'] == 1) {
                 $this->deductBalance($user['id'], $channel['price'], $model, 1);
             }
        }
    }

    private function deductBalance($userId, $amount, $model, $usageCount) {
        // 更新余额
        $stmt = $this->db->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $stmt->execute([$amount, $userId]);

        // 记录日志
        $stmt = $this->db->prepare("INSERT INTO logs (user_id, type, content, model_name, quota) VALUES (?, 2, 'API调用', ?, ?)");
        $stmt->execute([$userId, $model, $usageCount]);
    }

    private function jsonResponse($code, $message, $data = []) {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode([
            'error' => [
                'message' => $message,
                'type' => 'one_api_error',
                'code' => $code
            ]
        ]);
        exit;
    }
}

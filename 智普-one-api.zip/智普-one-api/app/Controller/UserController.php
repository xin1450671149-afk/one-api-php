<?php

class UserController {
    protected $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];

            $stmt = $this->db->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user'] = $user;
                // Log login
                // Redirect to dashboard
                header('Location: /dashboard');
                exit;
            } else {
                $error = "用户名或密码错误";
                require_once __DIR__ . '/../View/user/login.php';
            }
        } else {
            require_once __DIR__ . '/../View/user/login.php';
        }
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];

            if ($password !== $confirm_password) {
                $error = "两次密码输入不一致";
                require_once __DIR__ . '/../View/user/register.php';
                return;
            }

            // Check if user exists
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetchColumn() > 0) {
                $error = "用户名已存在";
                require_once __DIR__ . '/../View/user/register.php';
                return;
            }

            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $this->db->prepare("INSERT INTO users (username, password, balance, quota) VALUES (?, ?, 0.00, 10)");
            if ($stmt->execute([$username, $hashed_password])) {
                header('Location: /login?registered=1');
                exit;
            } else {
                $error = "注册失败，请稍后重试";
                require_once __DIR__ . '/../View/user/register.php';
            }
        } else {
            require_once __DIR__ . '/../View/user/register.php';
        }
    }

    public function logout() {
        session_destroy();
        header('Location: /login');
        exit;
    }

    public function dashboard() {
        if (!isset($_SESSION['user'])) {
            header('Location: /login');
            exit;
        }
        
        $user_id = $_SESSION['user']['id'];
        
        // Refresh user data
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        $_SESSION['user'] = $user;

        // Get Tokens
        $stmt = $this->db->prepare("SELECT * FROM tokens WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$user_id]);
        $tokens = $stmt->fetchAll();

        // Get Logs
        $stmt = $this->db->prepare("SELECT * FROM logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
        $stmt->execute([$user_id]);
        $logs = $stmt->fetchAll();

        require_once __DIR__ . '/../View/user/dashboard.php';
    }

    public function createToken() {
        if (!isset($_SESSION['user']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /login');
            exit;
        }

        $user_id = $_SESSION['user']['id'];
        $name = $_POST['name'];
        // Generate key: sk-randomstring (32 hex chars = 35 chars total, fits in varchar(48))
        $key = 'sk-' . bin2hex(random_bytes(16));
        
        $stmt = $this->db->prepare("INSERT INTO tokens (user_id, `key`, name, remain_quota, unlimited_quota) VALUES (?, ?, ?, 500000, 1)"); // Default quota
        $stmt->execute([$user_id, $key, $name]);
        
        header('Location: /dashboard');
        exit;
    }

    public function deleteToken() {
        if (!isset($_SESSION['user'])) {
            header('Location: /login');
            exit;
        }
        
        $id = $_GET['id'];
        $user_id = $_SESSION['user']['id'];
        
        $stmt = $this->db->prepare("DELETE FROM tokens WHERE id = ? AND user_id = ?");
        $stmt->execute([$id, $user_id]);
        
        header('Location: /dashboard');
        exit;
    }

    public function recharge() {
        if (!isset($_SESSION['user']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /login');
            exit;
        }

        $amount = floatval($_POST['amount']);
        if ($amount <= 0) {
             // Handle error
             header('Location: /dashboard?error=invalid_amount');
             exit;
        }

        // Simulate payment success immediately as per request (1:1 ratio)
        // In real world, integrate payment gateway here.
        
        $user_id = $_SESSION['user']['id'];
        
        // Update balance
        $stmt = $this->db->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->execute([$amount, $user_id]);
        
        // Log transaction
        $stmt = $this->db->prepare("INSERT INTO logs (user_id, type, content, quota) VALUES (?, 1, '充值成功', ?)");
        $stmt->execute([$user_id, $amount]); // Logging amount as quota for simplicity or separate field? Schema has `quota` int. Maybe need `amount` decimal in logs? 
        // Schema has `quota` int(11). The user request says "amount ratio 1:1". Usually 1 USD = 500000 quota (just an example). 
        // But the request says "Amount ratio 1:1". So 1 CNY = 1 Balance.
        // And quota usage depends on models.
        // Let's assume balance is used to buy quota or pay as you go.
        // "Recharge page, user input custom amount, amount ratio 1:1".
        // The logs should track quota consumption.
        // Maybe convert balance to quota? Or just add balance.
        // The requirement says: "3. Recharge page, user input custom amount, amount ratio 1:1".
        // "2. Model channel... set pricing...".
        // So consumption deducts from balance or quota? Usually quota.
        // Let's assume 1 Balance = 500000 Quota (standard OneAPI ratio is 1$ = 500000).
        // Or maybe just direct balance deduction.
        // The schema has `balance` and `quota`.
        // Let's stick to adding balance for now.
        
        header('Location: /dashboard?success=recharge');
        exit;
    }
}

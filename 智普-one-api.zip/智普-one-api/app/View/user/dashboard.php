<?php require_once __DIR__ . '/../layout/header.php'; ?>

<div style="display: flex; gap: 20px; margin-bottom: 20px;">
    <div class="card" style="flex: 1;">
        <h2>当前余额</h2>
        <div style="font-size: 32px; font-weight: bold; color: #28a745;">
            ¥ <?php echo number_format($user['balance'], 2); ?>
        </div>
        <div style="margin-top: 10px; color: #666;">
            剩余额度: <?php echo $user['quota']; ?>
        </div>
    </div>
    
    <div class="card" style="flex: 1;">
        <h2>充值中心</h2>
        <form method="POST" action="/recharge">
            <div style="display: flex; gap: 10px; align-items: flex-end;">
                <div class="form-group" style="flex: 1; margin-bottom: 0;">
                    <label>充值金额 (1:1)</label>
                    <input type="number" name="amount" min="1" step="0.01" placeholder="输入金额" required>
                </div>
                <button type="submit" class="btn btn-primary">立即充值</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
        <h2>API 令牌管理</h2>
        <button onclick="document.getElementById('createTokenModal').style.display='block'" class="btn btn-primary">新建令牌</button>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>名称</th>
                <th>密钥 (Key)</th>
                <th>剩余额度</th>
                <th>状态</th>
                <th>创建时间</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($tokens as $token): ?>
            <tr>
                <td><?php echo htmlspecialchars($token['name']); ?></td>
                <td>
                    <code style="background: #f0f0f0; padding: 4px; border-radius: 4px;">
                        <?php echo substr($token['key'], 0, 8) . '***' . substr($token['key'], -4); ?>
                    </code>
                    <button class="btn" style="padding: 2px 6px; font-size: 12px;" onclick="copyToClipboard('<?php echo $token['key']; ?>')">复制</button>
                </td>
                <td><?php echo $token['unlimited_quota'] ? '无限' : $token['remain_quota']; ?></td>
                <td>
                    <?php if ($token['status'] == 1): ?>
                        <span style="color: green;">正常</span>
                    <?php else: ?>
                        <span style="color: red;">禁用</span>
                    <?php endif; ?>
                </td>
                <td><?php echo $token['created_at']; ?></td>
                <td>
                    <a href="/token/delete?id=<?php echo $token['id']; ?>" class="btn btn-danger" onclick="return confirm('确定删除?')">删除</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="card">
    <h2>近期日志</h2>
    <table>
        <thead>
            <tr>
                <th>时间</th>
                <th>类型</th>
                <th>详情</th>
                <th>模型</th>
                <th>消耗</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($logs as $log): ?>
            <tr>
                <td><?php echo $log['created_at']; ?></td>
                <td>
                    <?php echo $log['type'] == 1 ? '<span style="color:green">充值</span>' : '<span style="color:orange">消费</span>'; ?>
                </td>
                <td><?php echo htmlspecialchars($log['content']); ?></td>
                <td><?php echo htmlspecialchars($log['model_name']); ?></td>
                <td><?php echo $log['quota']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<div id="createTokenModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5);">
    <div class="card" style="width: 400px; margin: 100px auto;">
        <h3>新建令牌</h3>
        <form method="POST" action="/token/create">
            <div class="form-group">
                <label>令牌名称</label>
                <input type="text" name="name" required placeholder="例如：测试Key">
            </div>
            <div style="text-align: right;">
                <button type="button" class="btn" onclick="document.getElementById('createTokenModal').style.display='none'">取消</button>
                <button type="submit" class="btn btn-primary">创建</button>
            </div>
        </form>
    </div>
</div>

<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        alert('已复制到剪贴板');
    }, function(err) {
        console.error('Async: Could not copy text: ', err);
    });
}
</script>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>

<?php require_once __DIR__ . '/../layout/header.php'; ?>

<div style="max-width: 400px; margin: 50px auto;">
    <div class="card">
        <h2 style="text-align: center; margin-bottom: 20px;">注册新账号</h2>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="/register">
            <div class="form-group">
                <label>用户名</label>
                <input type="text" name="username" required>
            </div>
            <div class="form-group">
                <label>密码</label>
                <input type="password" name="password" required>
            </div>
            <div class="form-group">
                <label>确认密码</label>
                <input type="password" name="confirm_password" required>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary" style="width: 100%;">注册</button>
            </div>
        </form>
        <div style="text-align: center; margin-top: 15px;">
            <a href="/login">已有账号？直接登录</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>

<?php require_once __DIR__ . '/../layout/header.php'; ?>

<div style="max-width: 400px; margin: 50px auto;">
    <div class="card">
        <h2 style="text-align: center; margin-bottom: 20px;">用户登录</h2>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if (isset($_GET['registered'])): ?>
            <div class="alert alert-success">注册成功，请登录</div>
        <?php endif; ?>

        <form method="POST" action="/login">
            <div class="form-group">
                <label>用户名</label>
                <input type="text" name="username" required>
            </div>
            <div class="form-group">
                <label>密码</label>
                <input type="password" name="password" required>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary" style="width: 100%;">登录</button>
            </div>
        </form>
        <div style="text-align: center; margin-top: 15px;">
            <a href="/register">没有账号？立即注册</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>

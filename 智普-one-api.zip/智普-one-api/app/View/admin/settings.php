<?php require_once __DIR__ . '/../layout/header.php'; ?>

<div class="card" style="max-width: 600px;">
    <h2>系统设置</h2>
    
    <form method="POST" action="/admin/settings">
        <div class="form-group">
            <label>网站名称</label>
            <input type="text" name="site_name" value="<?php echo htmlspecialchars($options['site_name'] ?? ''); ?>">
        </div>
        
        <div class="form-group">
            <label>支付开关 (1开启 0关闭)</label>
            <input type="number" name="payment_enabled" value="<?php echo htmlspecialchars($options['payment_enabled'] ?? '1'); ?>">
        </div>
        
        <div class="form-group">
            <label>注册赠送额度</label>
            <input type="number" name="register_quota" value="<?php echo htmlspecialchars($options['register_quota'] ?? '10'); ?>">
        </div>

        <button type="submit" class="btn btn-primary">保存设置</button>
    </form>
</div>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>

<?php require_once __DIR__ . '/../layout/header.php'; ?>

<div class="card">
    <h2>日志管理</h2>
    <table style="font-size: 14px;">
        <thead>
            <tr>
                <th>ID</th>
                <th>用户</th>
                <th>类型</th>
                <th>模型</th>
                <th>消耗</th>
                <th>详情</th>
                <th>时间</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($logs as $log): ?>
            <tr>
                <td><?php echo $log['id']; ?></td>
                <td><?php echo htmlspecialchars($log['username'] ?? '未知'); ?></td>
                <td><?php echo $log['type'] == 1 ? '<span style="color:green">充值</span>' : '<span style="color:orange">消费</span>'; ?></td>
                <td><?php echo htmlspecialchars($log['model_name'] ?? '-'); ?></td>
                <td><?php echo $log['quota']; ?></td>
                <td><?php echo htmlspecialchars($log['content']); ?></td>
                <td><?php echo $log['created_at']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <div style="margin-top: 15px;">
        <?php if ($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?>" class="btn">上一页</a>
        <?php endif; ?>
        <span>第 <?php echo $page; ?> 页</span>
        <a href="?page=<?php echo $page + 1; ?>" class="btn">下一页</a>
    </div>
</div>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>

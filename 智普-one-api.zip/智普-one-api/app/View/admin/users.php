<?php require_once __DIR__ . '/../layout/header.php'; ?>

<div class="card">
    <h2>用户管理</h2>
    
    <table style="font-size: 14px;">
        <thead>
            <tr>
                <th>ID</th>
                <th>用户名</th>
                <th>余额</th>
                <th>额度</th>
                <th>状态</th>
                <th>注册时间</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo $user['id']; ?></td>
                <td><?php echo htmlspecialchars($user['username']); ?></td>
                <td><?php echo $user['balance']; ?></td>
                <td><?php echo $user['quota']; ?></td>
                <td><?php echo $user['status'] == 1 ? '正常' : '封禁'; ?></td>
                <td><?php echo $user['created_at']; ?></td>
                <td>
                    <button class="btn" onclick="openBalanceModal(<?php echo $user['id']; ?>, '<?php echo $user['username']; ?>')">充值</button>
                    <?php if ($user['role'] != 1): ?>
                    <form method="POST" action="/admin/users" style="display:inline;" onsubmit="return confirm('确定删除?')">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                        <button type="submit" class="btn btn-danger">删除</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<div id="balanceModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5);">
    <div class="card" style="width: 400px; margin: 100px auto;">
        <h3>用户充值</h3>
        <p>为用户 <span id="balanceUsername" style="font-weight:bold;"></span> 增加余额</p>
        <form method="POST" action="/admin/users">
            <input type="hidden" name="action" value="add_balance">
            <input type="hidden" name="id" id="balanceUserId">
            
            <div class="form-group">
                <label>金额 (支持负数扣款)</label>
                <input type="number" step="0.01" name="amount" required>
            </div>
            
            <div style="text-align: right;">
                <button type="button" class="btn" onclick="document.getElementById('balanceModal').style.display='none'">取消</button>
                <button type="submit" class="btn btn-primary">确认</button>
            </div>
        </form>
    </div>
</div>

<script>
function openBalanceModal(id, username) {
    document.getElementById('balanceUserId').value = id;
    document.getElementById('balanceUsername').innerText = username;
    document.getElementById('balanceModal').style.display = 'block';
}
</script>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>

<?php require_once __DIR__ . '/../layout/header.php'; ?>

<div class="card">
    <h2>系统概况</h2>
    <div style="display: flex; gap: 20px; flex-wrap: wrap;">
        <div style="flex: 1; min-width: 200px; padding: 20px; background: #e3f2fd; border-radius: 8px;">
            <h3>用户总数</h3>
            <p style="font-size: 24px; font-weight: bold;"><?php echo $user_count; ?></p>
        </div>
        <div style="flex: 1; min-width: 200px; padding: 20px; background: #e8f5e9; border-radius: 8px;">
            <h3>渠道总数</h3>
            <p style="font-size: 24px; font-weight: bold;"><?php echo $channel_count; ?></p>
        </div>
        <div style="flex: 1; min-width: 200px; padding: 20px; background: #fff3e0; border-radius: 8px;">
            <h3>总消耗额度</h3>
            <p style="font-size: 24px; font-weight: bold;"><?php echo number_format($total_quota); ?></p>
        </div>
    </div>
</div>

<div class="card">
    <h2>快捷入口</h2>
    <div style="display: flex; gap: 10px;">
        <a href="/admin/channels" class="btn btn-primary">渠道管理</a>
        <a href="/admin/users" class="btn btn-primary">用户管理</a>
        <a href="/admin/logs" class="btn btn-primary">日志查询</a>
        <a href="/admin/settings" class="btn btn-primary">系统设置</a>
    </div>
</div>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>

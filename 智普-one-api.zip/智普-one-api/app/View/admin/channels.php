<?php require_once __DIR__ . '/../layout/header.php'; ?>

<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
        <h2>渠道管理</h2>
        <button onclick="openModal()" class="btn btn-primary">添加渠道</button>
    </div>
    
    <table style="font-size: 14px;">
        <thead>
            <tr>
                <th>ID</th>
                <th>名称</th>
                <th>类型</th>
                <th>模型</th>
                <th>计费</th>
                <th>状态</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($channels as $channel): ?>
            <tr>
                <td><?php echo $channel['id']; ?></td>
                <td><?php echo htmlspecialchars($channel['name']); ?></td>
                <td><?php echo $channel['type'] == 1 ? 'OpenAI' : '其他'; ?></td>
                <td><span title="<?php echo htmlspecialchars($channel['models']); ?>"><?php echo substr($channel['models'], 0, 20) . '...'; ?></span></td>
                <td>
                    <?php 
                        if ($channel['pricing_type'] == 1) echo '按次: ¥' . $channel['price'];
                        else echo '按Token: ¥' . $channel['price'];
                    ?>
                </td>
                <td>
                    <?php echo $channel['status'] == 1 ? '<span style="color:green">启用</span>' : '<span style="color:red">禁用</span>'; ?>
                </td>
                <td>
                    <button class="btn" onclick='editChannel(<?php echo json_encode($channel); ?>)'>编辑</button>
                    <form method="POST" action="/admin/channels" style="display:inline;" onsubmit="return confirm('确定删除?')">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $channel['id']; ?>">
                        <button type="submit" class="btn btn-danger">删除</button>
                    </form>
                    <button class="btn" onclick="alert('测试功能需配合后端API测试接口，暂未实装前端调用')">测试</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<div id="channelModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); overflow-y: auto;">
    <div class="card" style="width: 600px; margin: 50px auto;">
        <h3 id="modalTitle">添加渠道</h3>
        <form method="POST" action="/admin/channels">
            <input type="hidden" name="action" value="add" id="formAction">
            <input type="hidden" name="id" id="channelId">
            
            <div class="form-group">
                <label>渠道名称</label>
                <input type="text" name="name" id="name" required>
            </div>
            
            <div class="form-group">
                <label>类型</label>
                <select name="type" id="type">
                    <option value="1">OpenAI</option>
                    <option value="2">Azure</option>
                    <option value="3">Claude</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>代理地址 (Base URL)</label>
                <input type="text" name="base_url" id="base_url" placeholder="https://api.openai.com" required>
            </div>
            
            <div class="form-group">
                <label>密钥 (Key)</label>
                <textarea name="key" id="key" rows="3" required style="width:100%; border:1px solid #ddd;"></textarea>
                <small>一行一个密钥</small>
            </div>
            
            <div class="form-group">
                <label>支持模型</label>
                <input type="text" name="models" id="models" placeholder="gpt-3.5-turbo,gpt-4" required>
            </div>
            
            <div class="form-group">
                <label>计费类型</label>
                <select name="pricing_type" id="pricing_type">
                    <option value="1">按次 (每次调用扣除固定金额)</option>
                    <option value="2">按Token/字数 (每1000字符/Token扣除)</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>价格 (元)</label>
                <input type="number" step="0.0001" name="price" id="price" value="0.01" required>
                <small id="priceHelp">按次时建议0.01，按Token时建议0.001</small>
            </div>

            <div style="text-align: right;">
                <button type="button" class="btn" onclick="document.getElementById('channelModal').style.display='none'">取消</button>
                <button type="submit" class="btn btn-primary">保存</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('formAction').value = 'add';
    document.getElementById('modalTitle').innerText = '添加渠道';
    document.getElementById('channelId').value = '';
    document.getElementById('name').value = '';
    document.getElementById('type').value = '1';
    document.getElementById('base_url').value = '';
    document.getElementById('key').value = '';
    document.getElementById('models').value = 'gpt-3.5-turbo,gpt-4';
    document.getElementById('pricing_type').value = '1';
    document.getElementById('price').value = '0.01';
    document.getElementById('channelModal').style.display = 'block';
}

function editChannel(channel) {
    document.getElementById('formAction').value = 'edit';
    document.getElementById('modalTitle').innerText = '编辑渠道';
    document.getElementById('channelId').value = channel.id;
    document.getElementById('name').value = channel.name;
    document.getElementById('type').value = channel.type;
    document.getElementById('base_url').value = channel.base_url;
    document.getElementById('key').value = channel.key;
    document.getElementById('models').value = channel.models;
    document.getElementById('pricing_type').value = channel.pricing_type;
    document.getElementById('price').value = channel.price;
    document.getElementById('channelModal').style.display = 'block';
}
</script>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>

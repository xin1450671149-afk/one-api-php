    </div>
    <footer style="margin-top: 50px; text-align: center; padding: 20px; background: #f8f9fa; border-top: 1px solid #eee;">
        <p>&copy; <?php echo date('Y'); ?> <?php echo defined('SITE_NAME') ? SITE_NAME : 'One API'; ?>. All rights reserved.</p>
    </footer>
</body>
</html>

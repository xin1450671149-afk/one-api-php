<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $page_title = defined('SITE_NAME') ? SITE_NAME : 'One API';
    if (isset($this) && isset($this->db)) {
        try {
            $stmt = $this->db->prepare("SELECT value FROM options WHERE `key` = 'site_name'");
            $stmt->execute();
            $res = $stmt->fetch();
            if ($res && !empty($res['value'])) {
                $page_title = $res['value'];
            }
        } catch (Exception $e) {
            // Ignore DB errors in view
        }
    }
    ?>
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <style>
        .nav-link {
            padding: 10px 15px;
            display: block;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar container">
            <div class="logo">
                <a href="/" style="font-size: 24px; font-weight: bold; text-decoration: none; color: #333;">One API</a>
            </div>
            <nav>
                <ul>
                    <?php if (isset($_SESSION['user'])): ?>
                        <?php if ($_SESSION['user']['role'] == 1): ?>
                            <li><a href="/admin/dashboard" class="nav-link">管理后台</a></li>
                            <li><a href="/admin/channels" class="nav-link">渠道管理</a></li>
                            <li><a href="/admin/users" class="nav-link">用户管理</a></li>
                            <li><a href="/admin/logs" class="nav-link">日志</a></li>
                            <li><a href="/admin/settings" class="nav-link">设置</a></li>
                        <?php else: ?>
                            <li><a href="/dashboard" class="nav-link">仪表盘</a></li>
                        <?php endif; ?>
                        <li><a href="/logout" class="nav-link">退出 (<?php echo htmlspecialchars($_SESSION['user']['username']); ?>)</a></li>
                    <?php else: ?>
                        <li><a href="/login" class="nav-link">登录</a></li>
                        <li><a href="/register" class="nav-link">注册</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="container">

<?php require_once __DIR__ . '/layout/header.php'; ?>

<div class="card" style="text-align: center; padding: 50px;">
    <h1>One API 标准转发系统</h1>
    <p>高效、稳定、便捷的 AI 接口转发服务</p>
    <div style="margin-top: 30px;">
        <?php if (!isset($_SESSION['user'])): ?>
            <a href="/login" class="btn btn-primary" style="font-size: 18px; padding: 12px 24px;">立即登录</a>
            <a href="/register" class="btn" style="font-size: 18px; padding: 12px 24px; background: #6c757d; color: #fff;">注册账号</a>
        <?php else: ?>
            <a href="/dashboard" class="btn btn-primary" style="font-size: 18px; padding: 12px 24px;">进入控制台</a>
        <?php endif; ?>
    </div>
</div>

<div style="display: flex; gap: 20px; flex-wrap: wrap;">
    <div class="card" style="flex: 1; min-width: 300px;">
        <h3>统一接口</h3>
        <p>兼容 OpenAI 格式，支持多种模型，统一输出标准流。</p>
    </div>
    <div class="card" style="flex: 1; min-width: 300px;">
        <h3>灵活计费</h3>
        <p>支持按次、按 Token 计费，精确控制成本。</p>
    </div>
    <div class="card" style="flex: 1; min-width: 300px;">
        <h3>高并发</h3>
        <p>优化的转发逻辑，支持高并发请求，稳定可靠。</p>
    </div>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
